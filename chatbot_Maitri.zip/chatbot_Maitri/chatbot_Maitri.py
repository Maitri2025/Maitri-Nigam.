def chatbot():
    print("ChatBot: Hello! I am your chatbot. Type 'bye' to exit.")
    
    computer_info = {
        "cpu": "The CPU (Central Processing Unit) is the brain of a computer that executes instructions.",
        "ram": "RAM (Random Access Memory) is temporary memory used by a computer for quick access to data.",
        "hard drive": "A hard drive stores all the data on a computer, including the operating system and files.",
        "operating system": "An operating system manages computer hardware and software resources (e.g., Windows, macOS, Linux).",
        "gpu": "A GPU (Graphics Processing Unit) is responsible for rendering images, videos, and animations efficiently.",
        "motherboard": "The motherboard is the main circuit board that connects all computer components together.",
        "super computer": "A supercomputer is a class of extremely powerful computers that can process vast amounts of data very quickly.",
        "mainframe computer": "A mainframe computer is a powerful computer used by large organizations for critical operations.",
        "micro computer": "A microcomputer is a small, general-purpose computer designed for individual use.",
        "mini computer": "A minicomputer is a mid-sized computer used for tasks like managing databases or networks."
    }

    while True:
        user_input = input("You: ").strip().lower()

        if user_input in ["hi", "hello", "hey"]:
            print("ChatBot: Hello there!")
        elif "how are you" in user_input:
            print("ChatBot: I'm fine! Tell me about yourself.")
        elif "your name" in user_input:
            print("ChatBot: I'm a Python chatbot. You can call me whatever you like.")
        elif "let's talk" in user_input:
            print("ChatBot: What topic would you like to discuss? Say whatever you like.")
        elif "computer" in user_input:
            print("ChatBot: A computer is a machine designed to make tasks easier and solve problems quickly.")
            print("ChatBot: There are four main types of computers:")
            print("1. Supercomputer - A supercomputer is an extremely powerful computer that can process vast amounts of data very quickly.")
            print("2. Mainframe computer - A mainframe computer is a powerful system used by large organizations for critical operations.")
            print("3. Microcomputer - A microcomputer is a small, general-purpose computer designed for individual use.")
            print("4. Minicomputer - A minicomputer is a mid-sized computer used for tasks like managing databases or networks.")
        elif user_input in computer_info:
            print(f"ChatBot: {computer_info[user_input]}")
        elif "help" in user_input:
            print("ChatBot: I can chat with you. Try saying 'hi', asking my name, or asking how I am.")
        elif "bye" in user_input:
            print("ChatBot: Goodbye! Have a great day!")
            break
        else:
            print("ChatBot: Sorry, I didn't understand that.")

# Run the chatbot
chatbot()
